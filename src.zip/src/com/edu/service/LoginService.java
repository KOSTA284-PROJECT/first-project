package com.edu.service;

import com.edu.repository.UserRepository;
import com.edu.vo.User;

public class LoginService {

    UserRepository ur = new UserRepository();

    //로그인()
    public User login(String id, String password) {

        return null;
    }

    //회원가입()
    public void addUser(User user) {

    }

    //로그아웃()
    public void logout() {

    }

}
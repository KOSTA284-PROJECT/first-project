package com.edu.service;

import com.edu.vo.User;

public class OrangeMarketService {

    //서비스 Hasing...
    private LoginService loginService = new LoginService();

    User user;

    //회원가입()

    //로그인()

    //로그아웃()

    //로그인 검증이 완료 되면 -> 여러가지 기능 구현..

    //상품 등록()

    //상품 전체 조회() -> 상품 상세 조회

    //상품 검색() -> 1.텍스트로 검색, 2. 카테고리 검색  -> 상품 상세 조회

    //마이페이지() -> ~~값이 뜨면서 다음 값 입력 요청 -> 1.값 수정(), 2.회원탈퇴(), 3.내가 등록한 상품 조회(), 4.포인트 충전

}

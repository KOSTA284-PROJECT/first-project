package com.edu.repository;

import java.util.HashMap;
import java.util.Map;

import com.edu.vo.Product;
import com.edu.vo.User;

public class ProductRepository{

    Map<Integer, Product> products;

    public void setHashMap(Map<Integer, Product> products) {
        this.products = products;
    }

    public Map<Integer, Product> getHashMap() {
        return products;
    }

    public void add() {
        // TODO Auto-generated method stub

    }

    public void find() {
        // TODO Auto-generated method stub

    }

    public void update() {
        // TODO Auto-generated method stub

    }

    public void delete() {
        // TODO Auto-generated method stub

    }



}